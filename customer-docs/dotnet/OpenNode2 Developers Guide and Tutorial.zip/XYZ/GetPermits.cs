﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Windsor.Node2008.WNOSDomain;
using Windsor.Node2008.WNOSProviders;
using Windsor.Node2008.WNOSPlugin;
using Windsor.Commons.NodeDomain;

namespace Windsor.Node2008.WNOSPlugin.XYZ
{
    public class GetPermits : BaseWNOSPlugin, ISolicitProcessor
    {
        protected ISerializationHelper _serializationHelper;
        protected ICompressionHelper _compressionHelper;
        protected IRequestManager _requestManager;
        protected IDocumentManager _documentManager;
        protected ISettingsProvider _settingsProvider;
        protected DataRequest _dataRequest;
        
        //service parameters
        protected const string CONFIG_COMPRESS_RESULTS = "Compress Results (true or false)";
        protected bool _compressResults;

        //request parameters
        protected const string PARAM_PERMIT_STATUS_FILTER = "PermitStatus";
        protected string _permitStatus;

        public GetPermits()
        {
            ConfigurationArguments[CONFIG_COMPRESS_RESULTS] = null;
        }

        public void ProcessSolicit(string requestId)
        {
          AppendAuditLogEvent("Initializing {0} plugin ...", this.GetType().Name);

          GetServiceImplementation(out _serializationHelper);
          GetServiceImplementation(out _compressionHelper);
          GetServiceImplementation(out _requestManager);
          GetServiceImplementation(out _documentManager);
          GetServiceImplementation(out _settingsProvider);

          TryGetConfigParameter(CONFIG_COMPRESS_RESULTS, ref _compressResults);

          AppendAuditLogEvent("Loading request with id \"{0}\"", requestId);
          _dataRequest = _requestManager.GetDataRequest(requestId);
          AppendAuditLogEvent("Request loaded: {0}", _dataRequest);

          TryGetParameterByName(_dataRequest, "PermitStatus", ref _permitStatus); //added

          DataTable dt = GetPermitData(_permitStatus);

          string tempXmlPath = _settingsProvider.NewTempFilePath(".xml");

          dt.WriteXml(tempXmlPath);
          AppendAuditLogEvent("Attaching submission document to transaction \"{0}\"", _dataRequest.TransactionId);

          if (_compressResults)
          {
              //.zip the results before returning
              string tempZipPath = _settingsProvider.NewTempFilePath(".zip");
              _compressionHelper.CompressFile(tempXmlPath, tempZipPath);
              _documentManager.AddDocument(_dataRequest.TransactionId,
                  CommonTransactionStatusCode.Completed, null, tempZipPath);
          }
          else
          {
              _documentManager.AddDocument(_dataRequest.TransactionId,
              CommonTransactionStatusCode.Completed, null, tempXmlPath);
          }

        }

        private DataTable GetPermitData(string PermitStatus)
        {
            DataTable dt = new DataTable("Permits");
            dt.Columns.Add("PermitNumber");
            dt.Columns.Add("PermitteeName");
            dt.Columns.Add("PermitStatus");

            DataRow dr1 = dt.NewRow();
            dr1[0] = "111";
            dr1[1] = "ACME Incorporated";
            dr1[2] = "Active";
            dt.Rows.Add(dr1);

            DataRow dr2 = dt.NewRow();
            dr2[0] = "222";
            dr2[1] = "Feelgood Pharma Inc.";
            dr2[2] = "Active";
            dt.Rows.Add(dr2);

            DataRow dr3 = dt.NewRow();
            dr3[0] = "333";
            dr3[1] = "Industrial Chemical Corp";
            dr3[2] = "Expired";
            dt.Rows.Add(dr3);

            if (PermitStatus != null)
            {
                for (int i = (dt.Rows.Count - 1); i >= 0; i--)
                {
                    if (dt.Rows[i]["PermitStatus"].ToString() != PermitStatus)
                        dt.Rows[i].Delete();
                }
                dt.AcceptChanges();
            }

            return dt;
        }

    }
}
