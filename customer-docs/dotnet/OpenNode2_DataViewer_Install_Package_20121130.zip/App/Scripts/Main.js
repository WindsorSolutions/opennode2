/// <reference name="MicrosoftAjax.js" />
/// <reference name="Telerik.Web.UI.Common.Core.js" assembly="Telerik.Web.UI" />

var DVResizeGridTimeoutInstance = null;
var DVAjaxVariables = {};
var DVConfirmAlertOnOkCallback = null;
var DVFocusDialogControlId = null;

function OnDVMainSplitterLoad(sender, event) {
    DVResizeMainGridToWindow();
}
function OnDVMainPaneResized(sender, event) {
    DVResizeMainGridToWindow();
}
function DVResizeMainGridToWindow() {
    if (DVResizeGridTimeoutInstance != null) {
        clearTimeout(DVResizeGridTimeoutInstance);
        DVResizeGridTimeoutInstance = null;
    }
    DVResizeGridTimeoutInstance = setTimeout(function () {
        if (DVResizeGridTimeoutInstance != null) {
            var dvMainPane = $find(g_ClientIds.DVMainPane);
            var dvMainGrid = $find(g_ClientIds.DVMainGrid);
            var dvMainGridView = dvMainGrid.get_masterTableView();
            var dvMainGridViewElement = dvMainGridView.get_element();
            var innerHeight = dvMainPane.getInnerHeight();
            var innerWidth = dvMainPane.getInnerWidth();
            DVResizeGridTimeoutInstance = null;
            DVBestFitMainGridColumns(innerWidth);
            var jGridElement = $(dvMainGrid.get_element());
            var jViewElement = $(dvMainGridViewElement);
            var toolPane = $("#" + g_ClientIds.DVToolPane);
            var toolPaneHeight = toolPane.height();
            if (toolPaneHeight != null) {
                innerHeight -= toolPaneHeight;
            }
            var toolSecondaryPane = $("#" + g_ClientIds.DVToolSecondaryPane);
            var toolSecondaryPaneHeight = toolSecondaryPane.height();
            if (toolSecondaryPaneHeight != null) {
                innerHeight -= toolSecondaryPaneHeight;
            }
            if (innerHeight < 0) {
                innerHeight = 0;
            }
            if (innerWidth < 0) {
                innerWidth = 0;
            }
            var columns = dvMainGridView.get_columns();
            var startGridHeight = jGridElement.height();
            var startGridWidth = jGridElement.width();
            jGridElement.height(innerHeight);
            jGridElement.width(innerWidth);
            if (columns.length == 0) {
                jViewElement.width(innerWidth);
            }
            var endGridHeight = jGridElement.height();
            var endGridWidth = jGridElement.width();
            if ((startGridHeight != endGridHeight) || (startGridWidth != endGridWidth)) {
                DVAjaxVariables.MainGridHeight = innerHeight;
                DVAjaxVariables.MainGridWidth = innerWidth;
                DVSaveAjaxVariables();
                dvMainGrid.repaint();
            }
        }
    }, 1);
}
function DVRebindMainGrid() {
    var dvMainGrid = $find(g_ClientIds.DVMainGrid);
    dvMainGrid.get_masterTableView().rebind();
}
function DVGetDialogWindow(windowId) {
    var dvWindow = $find(windowId);
    return dvWindow;
}
function OnDVAddEditDataViewDialogDatabaseInputSelectedIndexChanged(sender, event) {
    UpdateAddEditDataViewDialogDatabaseEditDeleteButtonEnabledStatus();
}
function OnDVAddEditDataViewDialogDatabaseInputClientLoad(sender, event) {
    UpdateAddEditDataViewDialogDatabaseEditDeleteButtonEnabledStatus();
}
function OnDVAddEditDataViewDialogDatabaseEditButtonLoad(sender, event) {
    UpdateAddEditDataViewDialogDatabaseEditDeleteButtonEnabledStatus();
}
function OnDVAddEditDataViewDialogDatabaseDeleteButtonLoad(sender, event) {
    UpdateAddEditDataViewDialogDatabaseEditDeleteButtonEnabledStatus();
}
function DVAjaxRequestWithTarget(targetUniqueId) {
    var ajaxManager = $find(g_ClientIds.DVAjaxManager);
    ajaxManager.ajaxRequestWithTarget(targetUniqueId, "");
}

function UpdateComboBoxEditButtonEnabledStatus(comboBoxId, editButtonId) {
    var comboBox = $telerik.findComboBox(comboBoxId);
    if (comboBox != null) {
        var value = comboBox.get_value();
        var button = $telerik.findButton(editButtonId);
        if (button != null) {
            button.set_enabled(value != "");
        }
    }
}
function UpdateAddEditDataViewDialogDatabaseEditDeleteButtonEnabledStatus() {
    UpdateComboBoxEditButtonEnabledStatus(g_ClientIds.DVAddEditDataViewDialogDatabaseInput,
                                          g_ClientIds.DVAddEditDataViewDialogDatabaseEditButton);
    UpdateComboBoxEditButtonEnabledStatus(g_ClientIds.DVAddEditDataViewDialogDatabaseInput,
                                          g_ClientIds.DVAddEditDataViewDialogDatabaseDeleteButton);
}
function DVGetDomElementById(id) {
    return document.getElementById(id);
}
function DVGetRadElementById(id) {
    return $telerik.findControl(null, id);
}
function OnDVDataViewAddButtonClicked(sender, event) {
    DVShowAddEditDataViewDialog("");
}
function OnDVDataViewEditButtonClicked(sender, event) {
    var comboBox = $find(g_ClientIds.DVDataViewComboBox);
    DVShowAddEditDataViewDialog(comboBox.get_value());
}
function OnDVDataViewDeleteButtonClicked(sender, event) {
    sender.set_autoPostBack(false);
    var comboBox = $find(g_ClientIds.DVDataViewComboBox);
    var dataViewName = comboBox.get_value();
    if (dataViewName != "") {
        DVShowConfirmAlert("Are you sure you want to delete the data view \"" + dataViewName + "\"?",
                           function () {
                               sender.set_autoPostBack(true);
                               DVAjaxRequestWithTarget(g_UniqueIds.DVDataViewDeleteButton);
                           }
                           );
    }
}
function DVDataViewClearGridLayoutClicked(sender, event) {
    sender.set_autoPostBack(false);
    var comboBox = $find(g_ClientIds.DVDataViewComboBox);
    var dataViewName = comboBox.get_value();
    if (dataViewName != "") {
        DVShowConfirmAlert("Are you sure you want to clear the grid layout for the data view \"" + dataViewName + "\"?",
                           function () {
                               sender.set_autoPostBack(true);
                               DVAjaxRequestWithTarget(g_UniqueIds.DVDataViewClearGridLayout);
                           }
                           );
    }
}
function OnDVAddEditDataViewDialogDatabaseDeleteButtonClicked(sender, event) {
    sender.set_autoPostBack(false);
    var comboBox = $find(g_ClientIds.DVAddEditDataViewDialogDatabaseInput);
    var databaseName = comboBox.get_value();
    if (databaseName != "") {
        DVShowConfirmAlert("Are you sure you want to delete the database \"" + databaseName + "\"?",
                           function () {
                               sender.set_autoPostBack(true);
                               DVAjaxRequestWithTarget(g_UniqueIds.DVAddEditDataViewDialogDatabaseDeleteButton);
                           }
                           );
    }
}
function OnDVConfirmDialogOkButtonClicked(sender, event) {
    DVCloseWindowById("DVConfirmDialog");
    if (DVConfirmAlertOnOkCallback != null) {
        var callback = DVConfirmAlertOnOkCallback;
        DVConfirmAlertOnOkCallback = null;
        callback();
    }
}
function OnDVConfirmDialogCancelButtonClicked(sender, event) {
    DVConfirmAlertOnOkCallback = null;
    DVCloseWindowById("DVConfirmDialog");
}
function DVShowAddEditDataViewDialog(dataViewName) {
    var dvWindow = DVGetDialogWindow("DVAddEditDataViewDialog");
    var hiddenField = DVGetDomElementById(g_ClientIds.DVAddEditDataViewDialogHiddenFieldId);
    hiddenField.value = dataViewName;
    var doAjaxInit = false;
    DVShowHideImage(g_ClientIds.DVAddEditDataViewDialogCheckSelectStatementOkImage, false);

    $telerik.findTextBox(g_ClientIds.DVAddEditDataViewDialogNameInput).set_value("");
    $telerik.findTextBox(g_ClientIds.DVAddEditDataViewDialogSelectStatementInput).set_value("");

    if ((dataViewName != null) && (dataViewName != "")) {
        dvWindow.set_title("Edit Data View");
        dvWindow.set_iconUrl("Images/table_edit_16.png");
        doAjaxInit = true;
    } else {
        dvWindow.set_title("Add Data View");
        dvWindow.set_iconUrl("Images/table_add_16.png");
    }
    DVFocusDialogControlId = g_ClientIds.DVAddEditDataViewDialogNameInput;
    dvWindow.show();
    if (doAjaxInit) {
        var ajaxButton = $telerik.findButton(g_ClientIds.DVAddEditDataViewDialogAjaxButton);
        ajaxButton.click();
    }
}
function DVShowAddEditDatabaseDialog(databaseConnectionName) {
    var dvWindow = DVGetDialogWindow("DVAddEditDatabaseDialog");
    var hiddenField = DVGetDomElementById(g_ClientIds.DVAddEditDatabaseDialogHiddenFieldId);
    hiddenField.value = databaseConnectionName;
    var doAjaxInit = false;
    DVShowHideImage(g_ClientIds.DVAddEditDatabaseDialogCheckConnectionOkImage, false);

    $telerik.findTextBox(g_ClientIds.DVAddEditDatabaseDialogNameInput).set_value("");
    $telerik.findComboBox(g_ClientIds.DVAddEditDatabaseDialogDatabaseTypeInput).set_text("SQL Server");
    $telerik.findTextBox(g_ClientIds.DVAddEditDatabaseDialogConnectionStringInput).set_value("");

    if ((databaseConnectionName != null) && (databaseConnectionName != "")) {
        dvWindow.set_title("Edit Database");
        dvWindow.set_iconUrl("Images/database_edit_16.png");
        doAjaxInit = true;
    } else {
        dvWindow.set_title("Add Database");
        dvWindow.set_iconUrl("Images/database_add_16.png");
    }
    DVFocusDialogControlId = g_ClientIds.DVAddEditDatabaseDialogNameInput;
    dvWindow.show();
    if (doAjaxInit) {
        var ajaxButton = $telerik.findButton(g_ClientIds.DVAddEditDatabaseDialogAjaxButton);
        ajaxButton.click();
    }
}
function DVShowHideImage(clientId, doShow) {
    var image = DVGetDomElementById(clientId);
    if (doShow) {
        $telerik.removeCssClasses(image, ["DVHidden"]);
    } else {
        $telerik.addCssClasses(image, ["DVHidden"]);
    }
}
function OnDVAddEditDataViewDialogDatabaseAddButtonClicked(sender, event) {
    DVShowAddEditDatabaseDialog("");
}
function OnDVAddEditDataViewDialogDatabaseEditButtonClicked(sender, event) {
    var comboBox = $telerik.findComboBox(g_ClientIds.DVAddEditDataViewDialogDatabaseInput);
    DVShowAddEditDatabaseDialog(comboBox.get_value());
}
function OnDVAddEditDatabaseDialogCheckConnectionButtonClicked(sender, event) {
    DVShowHideImage(g_ClientIds.DVAddEditDatabaseDialogCheckConnectionOkImage, false);
    return false;
}
function OnDVAddEditDataViewDialogCheckSelectStatementButtonClicked(sender, event) {
    DVShowHideImage(g_ClientIds.DVAddEditDataViewDialogCheckSelectStatementOkImage, false);
    return false;
}
function OnDVTextBoxBlur(sender, event) {
    var textBox = $telerik.toTextBox(sender);
    var text = textBox.get_value();
    var newText = $.trim(text);
    if (newText != text) {
        textBox.set_value(newText);
    }
}
function OnDVTextBoxHover(sender, event) {
    DVSetTextBoxEmptyTextClass(sender);
}
function DVSetTextBoxEmptyTextClass(sender) {
    var textBox = $telerik.toTextBox(sender);
    if (textBox.get_value() == "") {
        var wrapper = textBox.get_wrapperElement();
        var textArea = wrapper.firstChild;
        var textAreaQuery = $(textArea);
        if (!textAreaQuery.hasClass("riEmpty")) {
            textAreaQuery.addClass("riEmpty");
        }
    }
}
function OnDVLoginDialogCancelButtonClicked(sender, event) {
    DVCloseWindowById("DVLoginDialog");
}
function OnDVAddEditDataViewDialogCancelButtonClicked(sender, event) {
    DVCloseWindowById("DVAddEditDataViewDialog");
}
function OnDVAddEditDatabaseDialogCancelButtonClicked(sender, event) {
    DVCloseWindowById("DVAddEditDatabaseDialog");
}
function OnDVErrorDialogOkButtonClicked(sender, event) {
    DVCloseWindowById("DVErrorDialog");
}
function OnDVAlertDialogOkButtonClicked(sender, event) {
    DVCloseWindowById("DVAlertDialog");
}
function OnDVEditFilterDialogOkButtonClicked(sender, event) {
    DVCloseWindowById("DVEditFilterDialog");
}
function DVCloseWindow(window) {
    window.close();
}
function DVCloseWindowById(windowId) {
    DVCloseWindow(DVGetDialogWindow(windowId));
}
function DVGetLastAjaxError() {
    var lastErrorField = DVAjaxVariables.LastErrorMessage;
    DVAjaxVariables.LastErrorMessage = null;
    if ((lastErrorField == null) || (lastErrorField == "")) {
        return null;
    }
    return lastErrorField;
}
function DVGetAjaxVariablesHiddenFieldValue() {
    var field = DVGetDomElementById(g_ClientIds.DVAjaxVariablesHiddenField);
    if ((field == null) || (field.value == null) || (field.value.length == 0)) {
        return null;
    }
    return field.value;
}
function DVGetAjaxVariables() {
    var ajaxVariablesHiddenFieldValue = DVGetAjaxVariablesHiddenFieldValue();
    if (ajaxVariablesHiddenFieldValue != null) {
        DVAjaxVariables = $.parseJSON(ajaxVariablesHiddenFieldValue);
    }
}
function DVSaveAjaxVariables() {
    var field = DVGetDomElementById(g_ClientIds.DVAjaxVariablesHiddenField);
    if (DVAjaxVariables != null) {
        field.value = JSON.stringify(DVAjaxVariables);
    } else {
        field.value = "";
    }
}
function DVShowErrorAlert(message) {
    var dvWindow = DVGetDialogWindow("DVErrorDialog");
    dvWindow.set_iconUrl("Images/error_16.png");
    dvWindow.set_title("Application Error");

    var labelMessage = $("#" + g_ClientIds.DVErrorDialogMessageLabelId);
    labelMessage.text(message);
    dvWindow.show();
}
function DVShowConfirmAlert(message, onOkCallback) {
    var dvWindow = DVGetDialogWindow("DVConfirmDialog");
    dvWindow.set_iconUrl("Images/help_16.png");
    dvWindow.set_title("Application Confirmation");

    var labelMessage = $("#" + g_ClientIds.DVConfirmDialogLabelId);
    labelMessage.text(message);
    DVConfirmAlertOnOkCallback = onOkCallback;
    dvWindow.show();
}
function DVShowAlert(message) {
    var dvWindow = DVGetDialogWindow("DVAlertDialog");
    dvWindow.set_iconUrl("Images/information_16.png");
    dvWindow.set_title("Application Alert");

    var labelMessage = $("#" + g_ClientIds.DVAlertDialogLabelId);
    labelMessage.text(message);
    dvWindow.show();
}
function OnDVAjaxManagerResponseStart(sender, event) {

}
function OnDVAjaxManagerResponseEnd(sender, event) {

    DVGetAjaxVariables();

    DVResizeMainGridToWindow();

    var lastError = DVGetLastAjaxError();
    if (lastError != null) {
        DVShowErrorAlert(lastError);
        return;
    }
    var eventTarget = event.get_eventTarget();
    if (eventTarget != null) {
        if (eventTarget.indexOf("DVAddEditDataViewDialogOkButton") >= 0) {
            DVCloseWindowById("DVAddEditDataViewDialog");
            //DVRebindMainGrid();
        } else if (eventTarget.indexOf("DVAddEditDatabaseDialogOkButton") >= 0) {
            DVCloseWindowById("DVAddEditDatabaseDialog");
        } else if (eventTarget.indexOf("DVAddEditDatabaseDialogCheckConnectionButton") >= 0) {
            DVShowHideImage(g_ClientIds.DVAddEditDatabaseDialogCheckConnectionOkImage, true);
        } else if (eventTarget.indexOf("DVAddEditDataViewDialogCheckSelectStatementButton") >= 0) {
            DVShowHideImage(g_ClientIds.DVAddEditDataViewDialogCheckSelectStatementOkImage, true);
        } else if (eventTarget.indexOf("DVDataViewDeleteButton") >= 0) {
            //DVRebindMainGrid();
        } else if (eventTarget.indexOf("DVEditFilterDialogOkButton") >= 0) {
            DVCloseWindowById("DVEditFilterDialog");
        } else if (eventTarget.indexOf("DVLoginDialogOkButton") >= 0) {
            DVCloseWindowById("DVLoginDialog");
        } else if (eventTarget.indexOf("DVDataViewExportAsCsv") >= 0) {
            DVDoAspNetFileDownload();
        }
    }
}
function OnDVDialogClientShow(sender, event) {

    var contentElement = sender.get_contentElement();
    var tableElement = $telerik.getElementByClassName(contentElement, "DVMainDialogTable");
    var windowSize = $telerik.getContentSize(contentElement);
    var tableSize = $telerik.getOuterSize(tableElement);
    var newHeight = sender.get_height() - (windowSize.height - tableSize.height) + 4;
    sender.set_height(newHeight);
    sender.center();
    if (DVFocusDialogControlId != null) {
        DVFocusControl(DVFocusDialogControlId);
        DVFocusDialogControlId = null;
    }
}
function DVSplitJavascriptArgsString(text) {
    return text.split(";;");
}
function OnDVDialogClientBeforeShow(sender, event) {

    var element = sender.get_element();
    var validationGroupNames = element.getAttribute("DVValidationGroupNames");
    if ((validationGroupNames != null) && (validationGroupNames != "")) {
        var validationGroupNamesArray = DVSplitJavascriptArgsString(validationGroupNames);
        DVResetPageValidationGroups(validationGroupNamesArray);
    }
}
function DVResetPageValidationGroups(validationGroupNamesArray) {
    var validator;
    if (validationGroupNamesArray.length > 0) {
        if (typeof Page_Validators !== 'undefined') {
            for (var i = 0; i < Page_Validators.length; i++) {
                validator = Page_Validators[i];
                for (var j = 0; j < validationGroupNamesArray.length; j++) {
                    var validationGroupName = validationGroupNamesArray[j];
                    if (validator.validationGroup == validationGroupName) {
                        validator.style.display = 'none';
                    }
                }
            }
        }
    }
}
function DVShowFilterDialog() {
    var dvWindow = DVGetDialogWindow("DVEditFilterDialog");
    dvWindow.set_iconUrl("Images/filter_16.png");
    dvWindow.set_title("Edit Filter");
    dvWindow.show();
}
function DVDataShowFilterDialogClicked(sender, event) {
    DVShowFilterDialog();
}
//function DVDataViewExportAsCsvClicked(sender, event) {
//    var dvMainGrid = $find(g_ClientIds.DVMainGrid);
//    var dvMainGridView = dvMainGrid.get_masterTableView();
//    DVShowAlert("Sorry, not implemented yet.");
//}
//function DVBestFitMainGridColumns(innerWidth) {
//    var dvMainGrid = $find(g_ClientIds.DVMainGrid);
//    var dvMainGridView = dvMainGrid.get_masterTableView();
//    var columns = dvMainGridView.get_columns();
//    if ((columns != null) && (columns.length > 0)) {
//        //innerWidth -= 7;
//        var columnMargin = 0;
//        var header = dvMainGrid.get_masterTableViewHeader();
//        var headerRow = header.HeaderRow;
//        var maxColumnWidth = 400;
//        var minColumnWidth = 20;
//        var longColumnWidth = 150;
//        var newWidth;
//        var oldWidth;
//        var colWidths = [];
//        var element;
//        var columnWidth;
//        var columnWidthPlusMargin;
//        var totalColumnWidth = 0;
//        var totalLongColumnWidth = 0;
//        var totalLongColumnWidthDiff = 0;
//        var numLongColumns = 0;
//        var i;
//        for (i = 0; i < columns.length; ++i) {
//            var column = columns[i];
//            element = column.get_element();
//            column.set_resizable(true);
//            var headerRowCell = headerRow.cells[i];
//            var saveInnerText = headerRowCell.innerHTML;
//            headerRowCell.innerHTML = "";
//            column._cachedBestFitSize = undefined;
//            column.resizeToFit();
//            columnWidth = column._cachedBestFitSize;
//            headerRowCell.innerHTML = saveInnerText;
//            colWidths[i] = columnWidth;
//            columnWidthPlusMargin = columnWidth + columnMargin;
//            totalColumnWidth += columnWidthPlusMargin;
//            if (columnWidth > maxColumnWidth) {
//                totalLongColumnWidth += columnWidthPlusMargin;
//                totalLongColumnWidthDiff += columnWidth - maxColumnWidth;
//                ++numLongColumns;
//            }
//        }
//        if (totalColumnWidth != innerWidth) {
//            var widthDiff = innerWidth - totalColumnWidth;
//            var addWidthPerColumn;
//            var resizeLongColumnsOnly = false;
////            if ((widthDiff < 0) && (totalLongColumnWidthDiff > 0)) {
////                // Attempt to shrink longer columns first
////                if (totalLongColumnWidthDiff >= -widthDiff) {
////                    resizeLongColumnsOnly = true;
////                    addWidthPerColumn = Math.round(widthDiff / numLongColumns);
////                    for (i = 0; i < columns.length; ++i) {
////                        oldWidth = colWidths[i];
////                        if (oldWidth > maxColumnWidth) {
////                            newWidth = oldWidth + addWidthPerColumn;
////                            widthDiff += oldWidth - newWidth;
////                            colWidths[i] = newWidth;
////                        }
////                    }
////                    widthDiff = 0;
////                }
////            }
//            addWidthPerColumn = Math.round(widthDiff / columns.length);
//            var sumWidth = 0;
//            for (i = 0; i < columns.length; ++i) {
//                column = columns[i];
//                if (i == (columns.length - 1)) {
//                    newWidth = innerWidth - sumWidth;
//                } else {
//                    newWidth = colWidths[i] + addWidthPerColumn;
//                }
//                if (newWidth < minColumnWidth) {
//                    newWidth = minColumnWidth;
//                }
//                dvMainGridView.resizeColumn(i, newWidth);
//                element = column.get_element();
//                columnWidth = element.offsetWidth;
//                sumWidth += columnWidth + columnMargin;
//            }
//        }
//        dvMainGrid.repaint();
//    }
//}
function DVSetColumnHeaderText(column, newText) {
    var element = column.get_element();
    var innerHtml = element.innerHTML;
    var endIndex = innerHtml.indexOf("</a>");
    if (endIndex > 0) {
        var startIndex = innerHtml.lastIndexOf("\">", endIndex - 1);
        if (startIndex > 0) {
            var text = innerHtml.substr(startIndex + 2, endIndex - startIndex - 2);
            var newInnerHTML = innerHtml.substr(0, startIndex + 2) + newText +
                innerHtml.substr(endIndex);
            element.innerHTML = newInnerHTML;
            return text;
        }
    }
    return "";
}
function DVBestFitMainGridColumns(innerWidth) {
    var dvMainGrid = $find(g_ClientIds.DVMainGrid);
    var dvMainGridView = dvMainGrid.get_masterTableView();
    var columns = dvMainGridView.get_columns();
    if ((columns != null) && (columns.length > 0)) {
        var header = dvMainGrid.get_masterTableViewHeader();
        var headerRow = header.HeaderRow;
        var maxColumnWidth = 380;
        var minColumnWidth = 40;
        var columnWidth;
        var i;
        var totalWidth = 0;
        var overMaxColumnWidthColumnIndexes = [];
        var overMaxColumnWidthColumnLengths = [];
        for (i = 0; i < columns.length; ++i) {
            var column = columns[i];
            column.set_resizable(true);
            column.resizeToFit();
            columnWidth = column._cachedBestFitSize;
            if (columnWidth > maxColumnWidth) {
                dvMainGridView.resizeColumn(i, maxColumnWidth);
                //                var jColumn = $(column.get_element());
                //                var jColumnWidth = jColumn.outerWidth();
                columnWidth = column.get_element().offsetWidth;
                overMaxColumnWidthColumnIndexes.push(i);
                overMaxColumnWidthColumnLengths.push(columnWidth);
            } else if (columnWidth < minColumnWidth) {
                dvMainGridView.resizeColumn(i, minColumnWidth);
                columnWidth = column.get_element().offsetWidth;
            }
            totalWidth += columnWidth;
        }
        if (totalWidth < innerWidth) {
            // Make sure we fill width completely, as necessary
            if (overMaxColumnWidthColumnIndexes.length > 0) {
                var widthDiff = innerWidth - totalWidth - 18;
                var addWidth = Math.floor(widthDiff / overMaxColumnWidthColumnIndexes.length);
                for (i = 0; i < overMaxColumnWidthColumnIndexes.length; ++i) {
                    var columnIndex = overMaxColumnWidthColumnIndexes[i];
                    columnWidth = overMaxColumnWidthColumnLengths[i];
                    var newColumnWidth = columnWidth + addWidth;
                    dvMainGridView.resizeColumn(columnIndex, newColumnWidth);
                }
            }
        }
        dvMainGrid.repaint();
    }
}
function DVDoAspNetFileDownload() {
    var expression = "window.location.href = '" + g_DVDownloadFilePageUrl + "?random=" + Math.random() + "';";
    setTimeout(expression, 0);
}
function DVLoginDialog() {
    var dvWindow = DVGetDialogWindow("DVLoginDialog");
    dvWindow.set_title("Admin Login");
    dvWindow.set_iconUrl("Images/key_16.png");
    dvWindow.show();
}
function OnDVLogInLinkButtonClicked() {
    DVLoginDialog();
    return false;
}
function DVFocusControl(controlId) {
    if (DVIsReallyVisibleById(controlId)) {
        var control = $find(controlId);
        if (control != null) {
            setTimeout(function () {
                control.focus();
                if (control.selectAllText != undefined) {
                    control.selectAllText();
                }
            }, 100);
        }
    }
}
function DVIsReallyVisibleById(elementId) {
    var queryId = '#' + elementId;
    var element = $(queryId);
    return DVIsReallyVisible(element);
}
function DVIsReallyVisible(element) {
    if (element != null) {
        return (element.is(':visible') && element.parents(':hidden').length == 0);
    }
    return false;
}
function OnDVLoginDialogActivate(sender, event) {
    DVFocusControl(g_ClientIds.DVPasswordInput);
}
